package com.example.qrtest;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;
import static androidx.core.content.FileProvider.getUriForFile;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private String randomString;
    private final Random random = new Random();

    private ImageView imageView;
    private TextView timerTextView;

    int expirationTime;
    //private final String jetsonNanoIp = "192.168.137.175";
    //private final int jetsonNanoPort = 8100; //

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        timerTextView = findViewById(R.id.timerTextView);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                shareImage();
            }
        });
        generateRandomString();
        showExpirationDialog();

    }
    private void generateRandomString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            char c = (char) (random.nextInt(26) + 'a');
            sb.append(c);
        }
        randomString = "3floor"+sb.toString();
    }
    private void generateQRCode(int expirationTime) {
        int width = 500;
        int height = 500;

        String currentT=getCurrentTime();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
            // 분 단위로 계산
        if(expirationTime>0){
            if (expirationTime <= 60) {
                calendar.add(Calendar.MINUTE, expirationTime);
            }
            // 시간 단위로 계산
            else {
                calendar.add(Calendar.HOUR_OF_DAY, expirationTime);
            }

            Date expirationTimeM = calendar.getTime();
            String ets = new SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault()).format(expirationTimeM);

            String qrCode=randomString+"nowtime"+currentT+"limittime"+ets;
            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            //sendQRCodeToServer(qrCode);
            try {
                BitMatrix bitMatrix = qrCodeWriter.encode(qrCode, BarcodeFormat.QR_CODE, width, height);
                Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
                for (int x = 0; x < width; x++) {
                    for (int y = 0; y < height; y++) {
                        bitmap.setPixel(x, y, bitMatrix.get(x, y) ? Color.BLACK : Color.WHITE);
                    }
                }
                imageView.setImageBitmap(bitmap);
            } catch (WriterException e) {
                e.printStackTrace();
            }
        }
    }

    private String getCurrentTime(){
        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault());
        return sdf.format(new Date());
    }
    private int showExpirationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("QR 코드 유효 시간 설정");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        builder.setView(input);

        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String inputString = input.getText().toString();
                if (!inputString.isEmpty()) {
                    // 사용자가 입력한 유효 시간 설정
                    expirationTime=Integer.parseInt(inputString);
                    // 타이머 시작
                    generateQRCode(expirationTime);
                    startTimer(expirationTime);
                }
            }
        });
        builder.setNegativeButton("취소", (dialog, which) -> dialog.cancel());

        builder.show();
        return 0;
    }
    private void startTimer(int expirationTime) {

        long millisFut=expirationTime*1000*60;
        new android.os.CountDownTimer(millisFut, 1000) {
            @SuppressLint("DefaultLocale")
            @Override
            public void onTick(long millisUntilFinished) {
                long seconds = millisUntilFinished/1000 ;
                timerTextView.setText(String.format("유효 시간: %d초", seconds));
            }

            public void onFinish() {
                timerTextView.setText("유효 시간 종료");

                // QR 코드 초기화
                generateRandomString();
                generateQRCode(expirationTime);
                showExpirationDialog();

            }
        }.start();
    }
/*
    private void sendQRCodeToServer(final String qrCodeData) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Socket socket = new Socket(jetsonNanoIp, jetsonNanoPort);
                    OutputStream outputStream = socket.getOutputStream();
                    outputStream.write(qrCodeData.getBytes());
                    outputStream.flush();
                    outputStream.close();
                    socket.close();
                    Log.d(TAG, "QR 코드 전송 완료");
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e(TAG, "QR 코드 전송 실패: " + e.getMessage());
                }
            }
        }).start();

    }
*/
    public void shareImage() {
        // 이미지 데이터 가져오기
        Bitmap bitmap = ((BitmapDrawable) imageView.getDrawable()).getBitmap();

        // 이미지 파일로 저장
        String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/shared_image.jpg";
        FileOutputStream out;
        try {
            out = new FileOutputStream(path);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.flush();
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 이미지 공유 인텐트 생성
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("image/*");
        Uri imageUri = getUriForFile(this, getApplicationContext().getPackageName() + ".fileprovider", new File(path));
        shareIntent.putExtra(Intent.EXTRA_STREAM, imageUri);

        // 공유 액션 호출
        startActivity(Intent.createChooser(shareIntent, "이미지 공유"));
    }
}